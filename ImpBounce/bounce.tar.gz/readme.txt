﻿This applet code was created by Oscar Söderlund, student in the 2011 course. He says it provides smoother motion, can handle many balls, and has a clean interface to the animation.

You are on your own with this, but use it if you like it!

Dag

